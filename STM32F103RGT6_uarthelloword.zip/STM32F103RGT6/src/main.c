#include <stddef.h>
#include <stdlib.h>
#include "stm32f10x.h"

//just simple delay for demonstration
void LoopDelay(volatile uint32_t n) {
	while(n > 0) n--;
}

int main(void){

	//processor starts up with pll configured for 72Mhz. Let's change that to 36Mhz

	RCC->CR |= (RCC_CR_HSION);					//turn on HSI oscillator (8Mhz)
	while(!(RCC->CR & RCC_CR_HSIRDY));			//wait until oscillator starts

	RCC->CFGR &= ~(RCC_CFGR_SW);				//set SYSCLK to HSI (for the PLL configuration)
	while((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI);	//wait until it switches

	RCC->CR &= ~(RCC_CR_PLLON);					//turn off PLL (to be able to change parameters)

	RCC->CFGR &= ~(RCC_CFGR_PLLSRC);			//select PLL input as HSI/2
	RCC->CFGR |= (RCC_CFGR_PLLMULL9);			//set PLL multiplier to x9

	RCC->CR |= RCC_CR_PLLON;					//turn PLL back on
	while(!(RCC->CR & RCC_CR_PLLRDY));			//wait until it locks

	RCC->CFGR = (RCC->CFGR | RCC_CFGR_SW_1) | (RCC->CFGR & ~(RCC_CFGR_SW_0)); 	//set SYSCLK to PLL
	while((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);	//wait until it switches

	RCC->CFGR |= (RCC_CFGR_MCO_SYSCLK);			//set MCO to output sysclk

	RCC->APB2ENR |= (RCC_APB2ENR_IOPCEN);		//enable Clock for GPIOC periph
	RCC->APB2ENR |= (RCC_APB2ENR_IOPAEN);		//enable Clock for GPIOA periph

	GPIOA->CRH |= GPIO_CRH_MODE8;				//set PA8 as output with drive strenght to 50Mhz
	GPIOA->CRH = ((GPIOA->CRH | GPIO_CRH_CNF8_1) & ~(GPIO_CRH_CNF8_0));	//set PA8 to push-pull alternate function

	GPIOA->CRH |= GPIO_CRH_MODE9;				//set PA9 as output with drive strenght to 50Mhz
	GPIOA->CRH = ((GPIOA->CRH | GPIO_CRH_CNF9_1) & ~(GPIO_CRH_CNF9_0));	//set PA9 to push-pull alternate function
	GPIOA->CRH |= GPIO_CRH_MODE10;				//set PA10 as output with drive strenght to 50Mhz
	GPIOA->CRH = ((GPIOA->CRH | GPIO_CRH_CNF10_1) & ~(GPIO_CRH_CNF10_0));	//set PA10 to push-pull alternate function

	GPIOC->CRH |= GPIO_CRH_MODE8_0;				//set PC8 as output with drive strenght to 10Mhz
	GPIOC->CRH &= ~(GPIO_CRH_CNF8_0 | GPIO_CRH_CNF8_1);	//set PC8 to push-pull normal operation

	RCC->APB2ENR |= (RCC_APB2ENR_USART1EN);		//enable Clock for USART1 periph

	USART1->BRR |= (39 << 4) | 1;				//set USART1 baud rate to 57600
	USART1->CR1 &= ~(USART_CR1_M);				//set USART1 working mode to 8/1
	USART1->CR1 |= USART_CR1_UE | USART_CR1_TE;				//enable USART1

	uint32_t buf[14] = {'H','e','l','l','o',' ','w','o','r','l','d','!','\r','\n'};

	while (1){

		for(uint32_t i = 0; i<14; i++){
			USART1->DR = buf[i];					//load new byte to be sent
			while(!(USART1->SR & USART_SR_TC));		//wait until byte is transferred
		}

		GPIOC->BSRR |= GPIO_BSRR_BS8;				//set PC8 HIGH
		LoopDelay(65000);
		LoopDelay(65000);
		LoopDelay(65000);
		LoopDelay(65000);

		GPIOC->BSRR |= GPIO_BSRR_BR8;				//set PC8 LOW
		LoopDelay(65000);
		LoopDelay(65000);
		LoopDelay(65000);
		LoopDelay(65000);

	}
}
