#include <stddef.h>
#include <stdlib.h>
#include "stm32f10x.h"

//just simple delay for demonstration
void LoopDelay(volatile uint32_t n) {
	while(n > 0) n--;
}

int main(void){

	RCC->APB2ENR |= (RCC_APB2ENR_IOPCEN);

	GPIOC->CRH |= GPIO_CRH_MODE8_0;				//set PC8 as output with drive strenght to 10Mhz
	GPIOC->CRH &= ~(GPIO_CRH_CNF8_0 | GPIO_CRH_CNF8_1);	//set PC8 to push-pull normal operation

	while (1){

		GPIOC->BSRR |= GPIO_BSRR_BS8;				//set PC8 HIGH
		LoopDelay(65000);
		LoopDelay(65000);
		LoopDelay(65000);
		LoopDelay(65000);

		GPIOC->BSRR |= GPIO_BSRR_BR8;				//set PC8 LOW
		LoopDelay(65000);
		LoopDelay(65000);
		LoopDelay(65000);
		LoopDelay(65000);

	}
}
